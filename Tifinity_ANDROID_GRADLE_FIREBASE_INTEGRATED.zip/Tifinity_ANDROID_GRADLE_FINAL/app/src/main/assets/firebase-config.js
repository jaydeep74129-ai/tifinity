/* Tifinity Firebase client configuration. Client config only; no service-account secret. */
window.TIFINITY_FIREBASE_CONFIG = {
  apiKey: "AIzaSyCzxpy1WEJN-nJ7Pk8Pf4iFnbMxaki8ZlU",
  authDomain: "tifinity-9e312.firebaseapp.com",
  projectId: "tifinity-9e312",
  storageBucket: "tifinity-9e312.firebasestorage.app",
  messagingSenderId: "770096933909",
  appId: "1:770096933909:web:84ef4deaa32af79901321c",
  measurementId: "G-D2425C59YC"
};
