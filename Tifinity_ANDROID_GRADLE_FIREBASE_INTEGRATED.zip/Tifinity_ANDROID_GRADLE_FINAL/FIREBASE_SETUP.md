# Tifinity Firebase Setup

Project: `tifinity-9e312`

Firebase Auth admin account already exists:
- Email: `mejaideepsharma@gmail.com`
- UID: `HT23ydkjgEZOgSisKIv0wzyANua2`

The Firebase password must be entered only at runtime. Do not put it in this file or source code.

Firestore collections:
- `categories`
- `items`

Published rules must remain exactly aligned with `firestore.rules` in this package.

The HTML contains the client Firebase configuration and loads the required Firebase Web SDK over HTTPS.
The companion `firebase-config.js` contains the same client configuration for reference; it does not contain
any password or service-account secret.

Admin cloud writes require Firebase Auth and the exact UID above. Local Admin login alone does not authorize
Firestore writes.

Real Firebase Auth/CRUD could not be executed in the build environment because outbound network access is
unavailable and the password is intentionally never stored in the project.
