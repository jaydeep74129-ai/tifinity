TIFINITY ANDROID GRADLE PROJECT
================================

This project packages the supplied Tifinity HTML into an Android WebView shell.
The updated HTML is at:
app/src/main/assets/index.html

Build:
./gradlew assembleDebug

The current environment used to prepare this ZIP does not include a Gradle executable
or Android SDK, so the Android build was not executed here. The Gradle source project
and wrapper configuration are included for Android Studio/Gradle use.

Existing Tifinity HTML is self-contained and uses browser/local storage for its current
local application data. The Android wrapper enables JavaScript and DOM storage and
requests location permission only when the WebView page asks for geolocation.
