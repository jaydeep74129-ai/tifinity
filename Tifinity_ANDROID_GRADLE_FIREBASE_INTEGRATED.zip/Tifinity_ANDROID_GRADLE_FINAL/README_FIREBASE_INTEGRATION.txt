TIFINITY FIREBASE INTEGRATION

Incremental backend integration on top of the existing Tifinity WebView project.

Preserved:
- Existing HTML/UI and menu functionality
- LocalStorage data and keys
- Admin login/Remember Password/7-tap access
- GPS/Maps/WhatsApp/cart/order behavior
- Existing Gradle/Android shell

Added:
- Firebase Web SDK (Auth + Firestore) via HTTPS CDN from the single HTML
- Firestore collections: categories, items
- Firebase Auth for the existing admin account only
- Authorized Firebase Admin UID: HT23ydkjgEZOgSisKIv0wzyANua2
- Authorized Firebase Admin email: mejaideepsharma@gmail.com
- LocalStorage -> Firestore migration using stable IDs and merge writes
- Real-time Firestore listeners
- LocalStorage fallback when Firebase is unavailable
- Authoritative Firestore security rules

Security:
- No Firebase password is stored in source, LocalStorage, Gradle, or documentation.
- No createUserWithEmailAndPassword() call exists in the application.
- No service-account key or private key exists in the project.
- Local Admin login does not itself grant Firestore write access; Firebase Auth UID is checked.
- Firestore rules permit writes only for UID HT23ydkjgEZOgSisKIv0wzyANua2.

Testing status:
- JavaScript syntax: PASSED.
- Local runtime tests: PASSED.
- Migration/CRUD logic tests: PASSED.
- Destructive global LocalStorage clear search: ZERO source operations.
- Real Firebase network/Auth/CRUD: NOT TESTED in this environment because outbound network
  access is unavailable here and the Firebase password is intentionally not stored or supplied.
- Android Gradle build: NOT TESTED because the supplied project has only gradle-wrapper.properties
  and no Gradle wrapper JAR/executable is available in this environment.
